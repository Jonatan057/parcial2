function guardarEstudiante(estudiante) {
  let lista = JSON.parse(localStorage.getItem("datos04.txt")) || [];
  lista.push(estudiante);
  localStorage.setItem("datos04.txt", JSON.stringify(lista));
  localStorage.setItem("resultados04.txt", JSON.stringify(lista)); 
}

function mostrarEstudiantes() {
  const lista = JSON.parse(localStorage.getItem("resultados04.txt")) || [];
  const tabla = document.getElementById("tabla-estudiantes");
  tabla.innerHTML = "";

  lista.forEach(e => {
    const fila = `<tr>
      <td>${e.id}</td>
      <td>${e.nombre}</td>
      <td>${e.nota1}</td>
      <td>${e.nota2}</td>
      <td>${e.promedio}</td>
    </tr>`;
    tabla.innerHTML += fila;
  });
}