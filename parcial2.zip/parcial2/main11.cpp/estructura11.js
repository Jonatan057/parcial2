function Estudiante(id, nombre, nota1, nota2) {
  this.id = id;
  this.nombre = nombre;
  this.nota1 = nota1;
  this.nota2 = nota2;
  this.promedio = ((nota1 + nota2) / 2).toFixed(2);
}

function crearEstudiante() {
  const id = document.getElementById("id").value;
  const nombre = document.getElementById("nombre").value;
  const nota1 = parseFloat(document.getElementById("nota1").value);
  const nota2 = parseFloat(document.getElementById("nota2").value);
  return new Estudiante(id, nombre, nota1, nota2);
}